export const companies = [
  {
    "id": "c1",
    "name": "Advantech",
    "description": "Bangalore based Technology firm specializing in the areas of Full Stack application development"
  },
  {
    "id": "c2",
    "name": "Lucida Technologies",
    "description": "Bangalore based Technology firm specializing in the areas of Digital and Analytics solutions, Machine Learning and Artificial Intelligence"
  }
  ];
  
  export const jobs = [
    {
      id: 'j1',
      title: 'Full Stack Developer',
      company: companies[0],
      description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.'
    },
    {
      id: 'j2',
      title: 'Devops Engineer',
      company: companies[1],
      description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.'
    }
  ];