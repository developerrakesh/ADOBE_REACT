import {connect} from 'react-redux';
import ShoppingList from './ShoppingList';
import {ListActions} from '../redux/Actions';

// redux state from store ==> props to Component [ ShoppingList]
// in ShoppingList this.props.items
function mapStateToProps(state) {
    return {
        items: state.items
    }
}

// props ==> addListItem ; view invokes this ==> dipatch to ActionCreators ==> Reducer
function mapDispatchToProps(dispatch) {
    return {
        addListItem: (item) => dispatch(ListActions.addItem(item)),
        removeListItem: (id) => dispatch(ListActions.removeItem(id)),
        removeAllListItems: () => dispatch(ListActions.removeAllItems())
    }
}

const ShoppingListContainer = connect(
    mapStateToProps,
    mapDispatchToProps
)(ShoppingList);

export default ShoppingListContainer;
