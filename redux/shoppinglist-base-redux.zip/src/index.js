import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

// import ShoppingList from './components/ShoppingList';
import ShoppingListContainer from './components/ShoppingListContainer';

import 'bootstrap/dist/css/bootstrap.min.css';

// redux
import {createStore, compose, applyMiddleware} from 'redux';
import {ListReducers} from './redux/ListReducers';
import logger from 'redux-logger';
import { Provider } from 'react-redux';


const store = createStore(ListReducers, compose(applyMiddleware(logger), window.__REDUX_DEVTOOLS_EXTENSION__()))


ReactDOM.render(<Provider store={store}><ShoppingListContainer/></Provider>, document.getElementById('root'));

