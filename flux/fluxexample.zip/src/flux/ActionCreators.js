import { ADD_ITEM, REMOVE_ITEM, REMOVE_ALL_ITEMS } from './ActionConstants';

import dispatcher from './Dispatcher';

function addListItem(item) {
    let action = {
        type : ADD_ITEM,
        item
    };
    dispatcher.dispatch(action);
}

function removeAllItems() {
    dispatcher.dispatch({
        type: REMOVE_ALL_ITEMS
    })
}

export default {
    addListItem: addListItem,
    removeAllItems
}