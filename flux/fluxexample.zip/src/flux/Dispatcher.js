import {Dispatcher} from 'flux';

let dispatcher = new Dispatcher();

export default dispatcher;