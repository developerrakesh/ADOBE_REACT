import { ADD_ITEM, REMOVE_ITEM, REMOVE_ALL_ITEMS } from './ActionConstants';

import EventEmitter from 'events';

import dispatcher from './Dispatcher';

import objectAssign from 'object-assign';

var shoppingList = {}; // state

let ListStore = objectAssign({}, EventEmitter.prototype, {
    getListItems: function() { return shoppingList},
    addChangeListener: function(handler) { this.on('change', handler)}
});
 
function addListItem(item) {
    shoppingList[item.id] = item;
    ListStore.emit('change');
}

function removeAllListItems() {
    shoppingList = {};
    ListStore.emit('change');
}

function handleActions(action) {
    if(action.type == ADD_ITEM) {
        addListItem(action.item);
    } else if( action.type == REMOVE_ALL_ITEMS) {
        removeAllListItems();
    }
}

dispatcher.register(handleActions);

export default ListStore;