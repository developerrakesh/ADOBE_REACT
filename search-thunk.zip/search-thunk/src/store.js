import { createStore, combineReducers, applyMiddleware } from 'redux';
import thunk from "redux-thunk";

import search from './reducers/SearchReducer';
import status from './reducers/StatusReducer';

export default createStore(
  combineReducers({
    search,
    status
  }),
  {},
  applyMiddleware(thunk)
)