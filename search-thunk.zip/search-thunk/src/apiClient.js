import axios from 'axios';

const SEARCH_URL = (title) => 'http://localhost:1234/movies?title=' + title;


const apiClient = {
  query(title) {
    title = encodeURIComponent(title);
    return axios.get(SEARCH_URL(title)).catch(error => {
           throw error;
    });
  }
}

export default apiClient;