import apiClient from "../apiClient";

export const searchRequest = () => ({
  type: "SEARCH_REQUEST"
});

export const searchSuccess = result => ({
  type: "SEARCH_SUCCESS",
  result
});

export const searchFailure = error => ({
  type: "SEARCH_FAILURE",
  error
});

const SearchActions = {
  search: title => {
    return dispatch => {
      dispatch(searchRequest());
      setTimeout(() => {
        apiClient
          .query(title)
          .then(response => {
            if (response.data.length > 0) {
              dispatch(searchSuccess(response.data[0]));
            } else {
              dispatch(searchFailure("Movie not found"));
            }
          })
          .catch(error => {
            dispatch(searchFailure("Network"));
          });
      }, 1000);

    };
  }
};

export default SearchActions;