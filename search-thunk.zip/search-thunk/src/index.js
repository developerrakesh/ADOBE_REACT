import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import { Provider } from 'react-redux';
import store from './store';
import SearchContainer from './components/SearchContainer';

ReactDOM.render(
    <Provider store={store}>
      <SearchContainer />
    </Provider>,
  document.getElementById('root')
);


