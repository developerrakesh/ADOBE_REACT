import React from 'react';
import { connect } from 'react-redux';

import MovieItem from './MovieItem';
import SearchInputForm from './SearchInputForm';
import SearchActions from '../actions/SearchActions'; 

const SearchContainer = (props) => (

  <main id='search-container'>
    <SearchInputForm 
      placeholder='Search movie title...'
      onSubmit={ (title) => props.search(title) }
    />
    {
      (props.searchStatus === 'SUCCESS')
      ? <MovieItem
          movie={props.result } />
      : null
    }
    {
      (props.searchStatus === 'PENDING')
      ? <section className='loading'>
          <img src='images/loading.gif' alt="loading..." />
        </section>
      : null
    }
    {
      (props.searchStatus === 'ERROR')
      ? <section className='error'> 
          <p className='error'>
            <i className="red exclamation triangle icon"></i>
            Error: { props.searchError }
          </p>
        </section>
      : null
    }
  </main>
);

const mapStateToProps = (state) => (
  {
    searchStatus: state.status.search,
    searchError: state.status.searchError,
    result: state.search
  }
);

const mapDispatchToProps = (dispatch) => (
  {
    search: (title) => {
      dispatch(SearchActions.search(title))
    }
  }
)

export default connect(mapStateToProps, mapDispatchToProps)(SearchContainer);