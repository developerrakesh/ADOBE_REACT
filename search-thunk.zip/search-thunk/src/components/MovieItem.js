import React from 'react';


const MovieItem = ({ movie}) => (
  <article className='movie'>
   
    <div className='info'>
      <div>
        <h2>Title : {movie.title}</h2>
        <p>Rank : {movie.rank}</p>
      </div>
    </div>
  </article>
)

export default MovieItem