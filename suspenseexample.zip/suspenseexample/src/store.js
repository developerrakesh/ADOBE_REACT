export default [
    {
        id: "1",
        name: "Elvis Presley",
        genre: "Rock and Roll"
       
    },
    {
        id: "2",
        name: "Beatles",
        genre: "Rock. Pop"
    },
    {
        id: "3",
        name: "Michael Jackson",
        genre: "Pop"
    },
    {
        id: "4",
        name: "Madonna",
        genre: "Pop"
    },
    {
        id: "5",
        name: "Queen",
        genre: "Rock"
    }
];
